#从 core 模块中导入 SegTrainer 类，这个类可能用于执行分割任务的训练和预测操作
from core import SegTrainer
#从 configs 模块中导入 MyConfig 类和 load_parser 函数。
# MyConfig 类用于存储和管理配置信息，load_parser 函数可能用于从命令行参数中加载配置
from configs import MyConfig, load_parser,BaseConfig
#导入 warnings 模块并忽略所有警告信息，这样可以避免在代码运行过程中出现不必要的警告提示
import warnings
warnings.filterwarnings("ignore")

#这是 Python 中常用的入口点判断语句，确保代码作为脚本直接运行时才会执行下面的代码块
if __name__ == '__main__':

#创建一个 MyConfig 类的实例 config，用于存储和管理配置信息
    config = MyConfig()
    # config = BaseConfig()
    config.init_dependent_config()

# If you want to use command-line arguments, please uncomment the following line
    # config = load_parser(config)

#创建一个 SegTrainer 类的实例 trainer，并将 config 对象作为参数传递给它
    trainer = SegTrainer(config)

    if config.is_testing:
        trainer.predict(config)
    else:    
        trainer.run(config)