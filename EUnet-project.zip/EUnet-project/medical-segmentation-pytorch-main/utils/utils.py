import os, random, torch, json
import numpy as np


def mkdir(path):
    if not os.path.exists(path):
        os.mkdir(path)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)


def get_writer(config, main_rank):
    if config.use_tb and main_rank:
        from torch.utils.tensorboard import SummaryWriter
        writer = SummaryWriter(config.tb_log_dir)
    else:
        writer = None
    return writer


def get_logger(config, main_rank):
    if main_rank:
        import sys
        from loguru import logger
        logger.remove()
        logger.add(sys.stderr, format="[{time:YYYY-MM-DD HH:mm}] {message}", level="INFO")

        log_path = f'{config.save_dir}/{config.logger_name}.log'
        logger.add(log_path, format="[{time:YYYY-MM-DD HH:mm}] {message}", level="INFO")
    else:
        logger = None
    return logger


def save_config(config):
    config_dict = vars(config)
    with open(f'{config.save_dir}/config.json', 'w') as f:
        json.dump(config_dict, f, indent=4)


def log_config(config, logger):
    keys = ['dataset', 'subset', 'num_class', 'model', 'encoder', 'decoder', 'loss_type', 
            'optimizer_type', 'lr_policy', 'total_epoch', 'train_bs', 'val_bs',  
            'train_num', 'val_num', 'gpu_num', 'num_workers', 'amp_training', 
            'DDP', 'kd_training', 'synBN', 'use_ema']

    config_dict = vars(config)
    infos = f"\n\n\n{'#'*25} Config Informations {'#'*25}\n" 
    infos += '\n'.join('%s: %s' % (k, config_dict[k]) for k in keys)
    infos += f"\n{'#'*71}\n\n"
    logger.info(infos)







def get_colormap(config):
    if config.colormap_path is not None and os.path.isfile(config.colormap_path):
        assert config.colormap_path.endswith('json')
        with open(config.colormap_path, 'r') as f:
            colormap_json = json.load(f)

        # 确保读取的颜色值转换为元组
        colormap = {int(k): tuple(v) for k, v in colormap_json.items()}

    else:
        if config.colormap == 'custom':
            # 严格黑白映射（仅背景和前景两类）
            colormap = {
                0: (0, 0, 0),  # 黑色（背景）
                1: (255, 255, 255)  # 白色（前景）
            }

            # 确保只包含两个类别（忽略其他类别）
            colormap_json = {str(k): list(v) for k, v in colormap.items() if k in [0, 1]}

        elif config.colormap == 'random':
            # 生成随机颜色（保持原有逻辑）
            random_colors = np.random.randint(0, 256, size=(config.num_class, 3)).tolist()
            colormap = {i: tuple(color) for i, color in enumerate(random_colors)}
            colormap_json = {str(k): list(v) for k, v in colormap.items()}

        else:
            raise ValueError(f'Unsupported colormap type: {config.colormap}.')

        # 保存颜色映射到JSON文件
        with open(f'{config.save_dir}/colormap.json', 'w') as f:
            json.dump(colormap_json, f, indent=1)

    # 提取颜色值列表，并确保只返回前两个类别（背景和前景）
    colormap = [color for color in colormap.values()]
    return colormap[:2]  # 强制只返回黑白两种颜色