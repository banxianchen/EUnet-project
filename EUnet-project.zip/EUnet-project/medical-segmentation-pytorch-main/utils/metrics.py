from torchmetrics import JaccardIndex, Dice ,Recall ,Specificity

#加入评估指标的函数
def get_seg_metrics(config, metric_name):
    if metric_name == 'iou':
        metrics = JaccardIndex(task='multiclass', num_classes=config.num_class, 
                                ignore_index=config.ignore_index, average='none',)
    elif metric_name == 'dice':
        metrics = Dice(num_classes=config.num_class, average='macro')
    elif metric_name == 'recall':
        metrics = Recall(
            task='multiclass',
            num_classes=config.num_class,
            ignore_index=config.ignore_index,
            average='macro'
        )
    elif metric_name == 'specificity':
        metrics = Specificity(
            task='multiclass',
            num_classes=config.num_class,
            ignore_index=config.ignore_index,
            average='macro'
        )
    else:
        raise ValueError(f'Unsupported metric: {metric_name}.\n')

    return metrics