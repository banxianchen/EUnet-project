from configs.base_config import BaseConfig

#此代码定义了一个名为 MyConfig 的类，它继承自 BaseConfig 类。
# MyConfig 类的作用是存储和管理与医学图像分割任务相关的配置信息，涵盖了数据集、模型、训练、验证、训练设置以及数据增强等多个方面的参数
class MyConfig(BaseConfig):
    def __init__(self,):
        super().__init__()
        # Dataset
        self.dataset = 'polyp'          #指定使用的数据集为息肉相关的数据集
        self.subset = 'CVC-ClinicDB'          #指定使用的数据集子集为 CVC-ClinicDB
        self.data_root = '/EUnet-project/medical-segmentation-pytorch-main/datasets/CVC-ClinicDB'
        self.use_test_set = False        #表示使用测试集

        # Model
        #self.model = 'unetpp'  #Supported models in model_hub: ['ducknet', 'resunet', 'resunetpp', 'unet', 'unetpp']
        self.model = 'smp'
        self.encoder = 'efficientnet-b7'
        self.decoder = 'unetpp'
        #encoder支持的模型集合
        #Available encoders are:['resnet18', 'resnet34', 'resnet50', 'resnet101', 'resnet152', 'resnext50_32x4d',
        # 'resnext101_32x4d', 'resnext101_32x8d', 'resnext101_32x16d', 'resnext101_32x32d', 'resnext101_32x48d',
        # 'dpn68', 'dpn68b', 'dpn92', 'dpn98', 'dpn107', 'dpn131', 'vgg11', 'vgg11_bn', 'vgg13', 'vgg13_bn', 'vgg16',
        # 'vgg16_bn', 'vgg19', 'vgg19_bn', 'senet154', 'se_resnet50', 'se_resnet101', 'se_resnet152', 'se_resnext50_32x4d',
        # 'se_resnext101_32x4d', 'densenet121', 'densenet169', 'densenet201', 'densenet161', 'inceptionresnetv2',
        # 'inceptionv4', 'efficientnet-b0', 'efficientnet-b1', 'efficientnet-b2', 'efficientnet-b3', 'efficientnet-b4',
        # 'efficientnet-b5', 'efficientnet-b6', 'efficientnet-b7', 'mobilenet_v2', 'xception', 'timm-efficientnet-b0',
        # 'timm-efficientnet-b1', 'timm-efficientnet-b2', 'timm-efficientnet-b3', 'timm-efficientnet-b4',
        # 'timm-efficientnet-b5', 'timm-efficientnet-b6', 'timm-efficientnet-b7', 'timm-efficientnet-b8',
        # 'timm-efficientnet-l2', 'timm-tf_efficientnet_lite0', 'timm-tf_efficientnet_lite1', 'timm-tf_efficientnet_lite2',
        # 'timm-tf_efficientnet_lite3', 'timm-tf_efficientnet_lite4', 'timm-resnest14d', 'timm-resnest26d', 'timm-resnest50d',
        # 'timm-resnest101e', 'timm-resnest200e', 'timm-resnest269e', 'timm-resnest50d_4s2x40d', 'timm-resnest50d_1s4x24d',
        # 'timm-res2net50_26w_4s', 'timm-res2net101_26w_4s', 'timm-res2net50_26w_6s', 'timm-res2net50_26w_8s', 'timm-res2net50_48w_2s',
        # 'timm-res2net50_14w_8s', 'timm-res2next50', 'timm-regnetx_002', 'timm-regnetx_004', 'timm-regnetx_006', 'timm-regnetx_008',
        # 'timm-regnetx_016', 'timm-regnetx_032', 'timm-regnetx_040', 'timm-regnetx_064', 'timm-regnetx_080', 'timm-regnetx_120',
        # 'timm-regnetx_160', 'timm-regnetx_320', 'timm-regnety_002', 'timm-regnety_004', 'timm-regnety_006', 'timm-regnety_008',
        # 'timm-regnety_016', 'timm-regnety_032', 'timm-regnety_040', 'timm-regnety_064', 'timm-regnety_080', 'timm-regnety_120',
        # 'timm-regnety_160', 'timm-regnety_320', 'timm-skresnet18', 'timm-skresnet34', 'timm-skresnext50_32x4d', 'timm-mobilenetv3_large_075',
        # 'timm-mobilenetv3_large_100', 'timm-mobilenetv3_large_minimal_100', 'timm-mobilenetv3_small_075', 'timm-mobilenetv3_small_100',
        # 'timm-mobilenetv3_small_minimal_100', 'timm-gernet_s', 'timm-gernet_m', 'timm-gernet_l', 'mit_b0', 'mit_b1', 'mit_b2', 'mit_b3',
        # 'mit_b4', 'mit_b5', 'mobileone_s0', 'mobileone_s1', 'mobileone_s2', 'mobileone_s3', 'mobileone_s4'].

        self.base_channel = 32          #设置模型的基础通道数

        # Training
        self.total_epoch = 200
        self.train_bs = 4              #设置训练时的批次大小为
        self.loss_type = 'ce_dice'           #指定使用的损失函数类型为交叉熵损失（Cross Entropy）
        self.optimizer_type = 'sgd'    #指定使用的优化器类型为 Adam 优化器

        # Validating
        #self.metrics = ['dice', 'iou', 'recall', 'specificity']
        self.metrics = ['dice', 'iou']  #指定用于验证的评估指标为 Dice 系数和交并比（IoU）
        self.val_bs = 1                 #设置验证时的批次大小为 1

        # Training setting
        self.use_ema = False            #表示不使用指数移动平均（EMA）技术
        self.logger_name = 'medseg_trainer'#设置日志记录器的名称为 medseg_trainer

        # Augmentation
        self.crop_size = 320            #设置随机裁剪的大小为 320x320
        self.randscale = [-0.5, 1.0]    #设置随机缩放的范围
        self.brightness = 0.5           #设置随机亮度调整的参数
        self.contrast = 0.5             #设置随机对比度调整的参数
        self.saturation = 0.5           #设置随机饱和度调整的参数
        self.h_flip = 0.5               #设置水平翻转的概率为 0.5
        self.v_flip = 0.5               #设置垂直翻转的概率为 0.5