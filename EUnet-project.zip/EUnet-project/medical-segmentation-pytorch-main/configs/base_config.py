import os


class BaseConfig:
    def __init__(self,):
        # Dataset
        self.dataset = None        #self.dataset：指定使用的数据集名称，初始值为 None。
        self.subset = None        #self.subset：指定数据集的子集名称，初始值为 None。
        self.dataroot = None        #self.dataroot：数据集的根目录路径，初始值为 None。
        self.num_class = -1        #self.num_class：数据集中的类别数量，初始值为 -1。
        self.ignore_index = 255        #self.ignore_index：在计算损失时需要忽略的像素索引，默认值为 255。
        self.num_channel = None        #self.num_channel：输入图像的通道数，初始值为 None。
        self.use_test_set = False        #self.use_test_set：是否使用测试集，默认不使用。

        # Model
        self.model = None               #self.model：使用的模型名称，初始值为None。
        self.encoder = None             #self.encoder：模型中编码器的名称，初始值为None。
        self.decoder = None             #self.decoder：模型中解码器的名称，初始值为None。
        self.encoder_weights = 'imagenet'     #self.encoder_weights：编码器的预训练权重，默认使用ImageNet预训练权重。
        self.base_channel = None        #self.base_channel：模型的基础通道数，初始值为None。

        # Training
        self.total_epoch = 200  #self.total_epoch：训练的总轮数，默认值为200。
        self.base_lr = 0.01     #self.base_lr：基础学习率，默认值为0.01。
        self.train_bs = 16      #self.train_bs：每个GPU上的训练批次大小，默认值为16。
        self.use_aux = False    #self.use_aux：是否使用辅助损失，默认不使用。
        self.aux_coef = None    #self.aux_coef：辅助损失的系数，初始值为None。

        # Validating
        self.metrics = ['dice']         #self.metrics：用于验证的评估指标列表，默认使用Dice系数，列表中的第一个指标将作为主要指标。
        self.val_bs = 16                #self.val_bs：每个GPU上的验证批次大小，默认值为16。
        self.begin_val_epoch = 0        #self.begin_val_epoch：开始进行验证的轮数，默认从第0轮开始。
        self.val_interval = 1           #self.val_interval：验证的轮数间隔，默认每1轮进行一次验证。
        self.val_img_stride = 1         #self.val_img_stride：验证时图像的步长，默认值为1。

        # Testing
        self.is_testing = False      #self.is_testing：是否处于测试模式，默认不处于测试模式。
        self.test_bs = 16           #self.test_bs：测试时的批次大小，默认值为16。
        self.test_data_folder = '/home/admin1/桌面/xdc/medical-segmentation-pytorch-main/datasets/CVC-ClinicDB/test/images' #self.test_data_folder：测试数据的文件夹路径，初始值为None。
        self.colormap = 'random'    #self.colormap：颜色映射的类型，默认使用随机颜色映射。
        self.colormap_path = None   #self.colormap_path：颜色映射文件的路径，初始值为None。
        self.save_mask = True       #self.save_mask：是否保存预测的掩码，默认保存。
        self.blend_prediction = False#self.blend_prediction：是否将预测结果与原始图像混合，默认混合。
        self.blend_alpha = 0.3      #self.blend_alpha：混合时预测结果的透明度，默认值为0.3。

        # Loss
        self.loss_type = 'ce'       #self.loss_type：使用的损失函数类型，默认使用交叉熵损失（CE）。
        self.class_weights = None   #self.class_weights：每个类别的权重，初始值为None。
        self.ohem_thrs = 0.7        #self.ohem_thrs：在线困难样本挖掘（OHEM）的阈值，默认值为0.7。
        self.reduction = 'mean'     #self.reduction：损失函数的缩减方式，默认取平均值。

        # Scheduler
        self.lr_policy = 'cos_warmup'#self.lr_policy：学习率调整策略，默认使用余弦退火预热策略。
        self.warmup_epochs = 3       #self.warmup_epochs：预热的轮数，默认值为3

        # Optimizer



        self.optimizer_type = 'sgd' #self.optimizer_type：使用的优化器类型，默认使用随机梯度下降（SGD）。
        self.momentum = 0.9         #self.momentum：SGD优化器的动量参数，默认值为0.9。
        self.weight_decay = 1e-4    #self.weight_decay：SGD优化器的权重衰减参数，默认值为1e-4。

        # Monitoring
        self.save_ckpt = True
        self.save_dir = 'save'
        self.use_tb = True          # tensorboard
        self.tb_log_dir = None
        self.ckpt_name = None
        self.logger_name = None

        # Training setting
        self.amp_training = False
        self.resume_training = True
        self.load_ckpt = True
        self.load_ckpt_path = None
        #self.load_ckpt_path = 'save/best.pth'
        self.base_workers = 8
        self.random_seed = 1
        self.use_ema = False

        # Augmentation
        self.crop_size = 512
        self.crop_h = None
        self.crop_w = None
        self.scale = 1.0
        self.randscale = 0.0
        self.brightness = 0.0
        self.contrast = 0.0
        self.saturation = 0.0
        self.h_flip = 0.0
        self.v_flip = 0.0

        # DDP
        self.synBN = True
        self.destroy_ddp_process = True
        self.local_rank = int(os.getenv('LOCAL_RANK', -1))
        self.main_rank = self.local_rank in [-1, 0]

        # Knowledge Distillation
        self.kd_training = False
        self.teacher_ckpt = ''
        self.teacher_model = 'smp'
        self.teacher_encoder = None
        self.teacher_decoder = None
        self.kd_loss_type = 'kl_div'
        self.kd_loss_coefficient = 1.0
        self.kd_temperature = 4.0

    def init_dependent_config(self):
        assert len(self.metrics) > 0

        if self.load_ckpt_path is None and not self.is_testing:
            self.load_ckpt_path = f'{self.save_dir}/'
            #之前模型的last.pth会对之后的模型不适配
            #self.load_ckpt_path = f'{self.save_dir}/last.pth'

        if self.tb_log_dir is None:
            self.tb_log_dir = f'{self.save_dir}/tb_logs/'

        if self.crop_h is None:
            self.crop_h = self.crop_size

        if self.crop_w is None:
            self.crop_w = self.crop_size

        if self.dataset == 'polyp':
            self.num_class = 2 if self.num_class == -1 else self.num_class
            self.num_channel = 3 if self.num_channel is None else self.num_channel