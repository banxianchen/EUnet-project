import torch
import torch.nn as nn
import torch.nn.functional as F


# 在线困难样本挖掘交叉熵损失（原有代码）
class OhemCELoss(nn.Module):
    def __init__(self, thresh, ignore_index=255):
        super().__init__()
        self.thresh = -torch.log(torch.tensor(thresh, requires_grad=False, dtype=torch.float)).cuda()
        self.ignore_index = ignore_index
        self.criteria = nn.CrossEntropyLoss(ignore_index=ignore_index, reduction='none')

    def forward(self, logits, labels):
        n_min = labels[labels != self.ignore_index].numel() // 16
        loss = self.criteria(logits, labels).view(-1)
        loss_hard = loss[loss > self.thresh]
        if loss_hard.numel() < n_min:
            loss_hard, _ = loss.topk(n_min)
        return torch.mean(loss_hard)


# 新增：Dice损失函数
class DiceLoss(nn.Module):
    def __init__(self, ignore_index=255, smooth=1e-5):
        super().__init__()
        self.ignore_index = ignore_index  # 需要忽略的标签
        self.smooth = smooth  # 平滑因子，避免除零

    def forward(self, logits, labels):
        # logits: [batch_size, num_classes, H, W]
        # labels: [batch_size, H, W]

        # 忽略指定索引的像素
        mask = (labels != self.ignore_index)
        labels = labels.where(mask, torch.zeros_like(labels))  # 将忽略的像素设为0（不影响计算）

        # 转换为one-hot编码
        num_classes = logits.shape[1]
        labels_onehot = F.one_hot(labels, num_classes=num_classes).permute(0, 3, 1, 2).float()
        logits_softmax = F.softmax(logits, dim=1)  # 转换为概率分布

        # 只计算非忽略区域
        logits_softmax = logits_softmax * mask.unsqueeze(1).float()
        labels_onehot = labels_onehot * mask.unsqueeze(1).float()

        # 计算交并集
        intersection = torch.sum(logits_softmax * labels_onehot, dim=(2, 3))
        union = torch.sum(logits_softmax + labels_onehot, dim=(2, 3))

        # 计算Dice系数
        dice = (2. * intersection + self.smooth) / (union + self.smooth)
        return 1 - torch.mean(dice)  # Dice损失 = 1 - Dice系数


# 新增：混合损失函数（CE + Dice，1:1权重）
class HybridCELoss(nn.Module):
    def __init__(self, ignore_index=255, weight_ce=1.0, weight_dice=1.0, class_weights=None):
        super().__init__()
        # 交叉熵损失
        self.ce_loss = nn.CrossEntropyLoss(
            ignore_index=ignore_index,
            reduction='mean',
            weight=class_weights
        )
        # Dice损失
        self.dice_loss = DiceLoss(ignore_index=ignore_index)
        # 权重
        self.weight_ce = weight_ce
        self.weight_dice = weight_dice

    def forward(self, logits, labels):
        ce = self.ce_loss(logits, labels)
        dice = self.dice_loss(logits, labels)
        # 加权求和（1:1）
        return self.weight_ce * ce + self.weight_dice * dice


# 修改：获取损失函数的逻辑
def get_loss_fn(config, device):
    if config.class_weights is None:
        weights = None
    else:
        weights = torch.Tensor(config.class_weights).to(device)

    if config.loss_type == 'ce':
        criterion = nn.CrossEntropyLoss(
            ignore_index=config.ignore_index,
            reduction=config.reduction,
            weight=weights
        )
    elif config.loss_type == 'ohem':
        criterion = OhemCELoss(
            thresh=config.ohem_thrs,
            ignore_index=config.ignore_index
        )
    # 新增：支持混合损失
    elif config.loss_type == 'ce_dice':
        criterion = HybridCELoss(
            ignore_index=config.ignore_index,
            weight_ce=1.0,  # 交叉熵权重
            weight_dice=1.0,  # Dice权重（1:1）
            class_weights=weights
        )
    else:
        raise NotImplementedError(f"Unsupport loss type: {config.loss_type}")

    return criterion


def kd_loss_fn(config, outputs, outputsT):
    if config.kd_loss_type == 'kl_div':
        lossT = F.kl_div(F.log_softmax(outputs/config.kd_temperature, dim=1),
                    F.softmax(outputsT.detach()/config.kd_temperature, dim=1)) * config.kd_temperature ** 2

    elif config.kd_loss_type == 'mse':
        lossT = F.mse_loss(outputs, outputsT.detach())

    return lossT